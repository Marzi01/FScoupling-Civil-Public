# cfdem-offshore_windmill_foundation
Contains CFDEMcoupling-PUBLIC case files for simulating the erosion of soil at the foundation of an offshore windmill
